from flask import Flask, render_template, redirect, url_for, request, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, login_required, logout_user, current_user, UserMixin
import os

app = Flask(__name__)
app.secret_key = "cafeteria-secret"
basedir = os.path.abspath(os.path.dirname(__file__))
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(basedir, "cafeteria.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)  # stored plain in this demo
    role = db.Column(db.String(20), default="user")  # admin / user

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(50), nullable=False)  # Food / Drink
    image = db.Column(db.String(200), nullable=True)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    total_price = db.Column(db.Float, nullable=False, default=0)
    status = db.Column(db.String(20), default="Pending")

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("order.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("product.id"), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if User.query.filter_by(username=username).first():
            flash("Username exists")
            return redirect(url_for("register"))
        u = User(username=username, password=password)
        db.session.add(u)
        db.session.commit()
        flash("Account created. Please login.")
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        user = User.query.filter_by(username=username).first()
        if user and user.password == password:
            login_user(user)
            return redirect(url_for("dashboard"))
        flash("Invalid credentials")
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    # show user orders
    from sqlalchemy import desc
    orders = []
    conn = db.session
    # basic order history
    orders = conn.query(Order).filter_by(user_id=current_user.id).order_by(desc(Order.id)).all()
    return render_template("dashboard.html", orders=orders)

@app.route("/menu")
@login_required
def menu():
    q = request.args.get("q","")
    category = request.args.get("category","")
    products = Product.query
    if q:
        products = products.filter(Product.name.ilike(f"%{q}%"))
    if category:
        products = products.filter_by(category=category)
    products = products.all()
    return render_template("menu.html", products=products, q=q, category=category)

@app.route("/add_to_cart/<int:product_id>")
@login_required
def add_to_cart(product_id):
    cart = session.get("cart", {})
    cart[str(product_id)] = cart.get(str(product_id), 0) + 1
    session["cart"] = cart
    flash("Added to cart")
    return redirect(url_for("menu"))

@app.route("/cart")
@login_required
def cart():
    cart = session.get("cart", {})
    items = []
    total = 0
    for pid, qty in cart.items():
        p = Product.query.get(int(pid))
        if p:
            items.append({"product": p, "qty": qty})
            total += p.price * qty
    return render_template("cart.html", items=items, total=total)

@app.route("/checkout", methods=["POST","GET"])
@login_required
def checkout():
    cart = session.get("cart", {})
    if not cart:
        flash("Cart empty")
        return redirect(url_for("menu"))
    total = 0
    order = Order(user_id=current_user.id, total_price=0, status="Pending")
    db.session.add(order)
    db.session.commit()
    for pid, qty in cart.items():
        p = Product.query.get(int(pid))
        if p:
            oi = OrderItem(order_id=order.id, product_id=p.id, quantity=qty)
            db.session.add(oi)
            total += p.price * qty
    order.total_price = total
    db.session.commit()
    session["cart"] = {}
    flash("Order placed")
    return redirect(url_for("dashboard"))

# Admin routes
def admin_required():
    return current_user.is_authenticated and current_user.role == "admin"

@app.route("/admin")
@login_required
def admin_index():
    if not admin_required():
        return "Access denied"
    return render_template("admin_dashboard.html")

@app.route("/admin/products", methods=["GET","POST"])
@login_required
def admin_products():
    if not admin_required():
        return "Access denied"
    if request.method == "POST":
        name = request.form["name"]
        price = float(request.form["price"])
        category = request.form["category"]
        image = request.form["image"]
        p = Product(name=name, price=price, category=category, image=image)
        db.session.add(p)
        db.session.commit()
        flash("Product added")
        return redirect(url_for("admin_products"))
    products = Product.query.all()
    return render_template("admin_products.html", products=products)

@app.route("/admin/products/delete/<int:pid>")
@login_required
def admin_delete_product(pid):
    if not admin_required():
        return "Access denied"
    p = Product.query.get(pid)
    if p:
        db.session.delete(p)
        db.session.commit()
    return redirect(url_for("admin_products"))

@app.route("/admin/orders")
@login_required
def admin_orders():
    if not admin_required():
        return "Access denied"
    orders = Order.query.all()
    return render_template("admin_orders.html", orders=orders)

@app.route("/admin/orders/update/<int:order_id>/<status>")
@login_required
def admin_update_order(order_id, status):
    if not admin_required():
        return "Access denied"
    o = Order.query.get(order_id)
    if o:
        o.status = status
        db.session.commit()
    return redirect(url_for("admin_orders"))

if __name__ == "__main__":
    app.run(debug=True)
